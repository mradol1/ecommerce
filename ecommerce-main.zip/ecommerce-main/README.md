# ecommerce
To run this website you need to first download and install alocalhost server like for example XAMPP.

  1. &nbsp; Download the scripts from this repository, and unzip this 
     to "C:\xampp\htdocs\midterm_db" the "midterm_db" is a new folder you need to create.
  2. &nbsp; If you already downloaded XAMPP, open it and activate "Apache" and "MySQL", and type 
     "http://localhost/phpmyadmin/" in you browser.
  2. &nbsp; In PhpMyadmin of XAMPP, create a new database "midterm_db" by clicking the "new" 
     tab on the left side.
  3. &nbsp; Locate the SQL file "midterm_db" in the downloaded scripts and import it to the 
     previously created database of the same name in PhpMyadmin.
  4. &nbsp; In your browser go to "http://localhost/midterm_db/l_login_page.php" 
